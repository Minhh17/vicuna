# Hardware design directory

This directory contains the hardware design sources of the vector processor.
